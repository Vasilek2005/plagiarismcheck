#include <crow.h>
#include <curl/curl.h>
#include <json/json.h>

size_t writeCallback(char* buf, size_t size, size_t nmemb, std::string* data) {
    data->append(buf, size * nmemb);
    return size * nmemb;
}

std::vector<std::string> getFoundSourcesFromInternet(std::string query) {
    std::string apiKey = "AIzaSyCTgC8b-Xm4GWcBASbEXxFNkj97uFI5JYw";

    std::string cx = "358971a2682be4753";

    std::string encodedQuery;
    CURL* curl_handle = curl_easy_init();
    if (curl_handle) {
        encodedQuery = curl_easy_escape(curl_handle, query.c_str(), query.length());
        curl_easy_cleanup(curl_handle);
    }

    std::string searchUrl = "https://www.googleapis.com/customsearch/v1?key=" + apiKey + "&cx=" + cx + "&q=" + encodedQuery;

    curl_global_init(CURL_GLOBAL_ALL);
    CURL* curl = curl_easy_init();
    if (!curl) {
        std::cerr << "Failed to initialize libcurl." << std::endl;
        return {};
    }

    curl_easy_setopt(curl, CURLOPT_URL, searchUrl.c_str());

    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);

    std::string response;

    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeCallback);

    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);

    CURLcode res = curl_easy_perform(curl);
    if (res != CURLE_OK) {
        std::cerr << "Failed to perform request: " << curl_easy_strerror(res) << std::endl;
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return {};
    }

    Json::Reader reader;
    Json::Value root;
    if (!reader.parse(response, root)) {
        std::cerr << "Failed to parse JSON response." << std::endl;
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return {};
    }

    std::vector<std::string> sources = {};

    for (const auto& item : root["items"]) {
        sources.push_back(item["link"].asString());
    }

    curl_easy_cleanup(curl);
    curl_global_cleanup();

    return sources;
}

std::string translateText(const std::string& target_language, const std::string& text_to_translate) {
    // Construct the request URL
    std::string url = "https://microsoft-translator-text.p.rapidapi.com/translate?to%5B0%5D=" + target_language + "&api-version=3.0&profanityAction=NoAction&textType=plain";

    // Construct the request body
    Json::Value requestBody;
    Json::Value textObject;
    textObject["Text"] = text_to_translate;
    requestBody.append(textObject);
    std::string requestBodyStr = requestBody.toStyledString();

    // Set up CURL
    CURL* curl;
    curl = curl_easy_init();
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        struct curl_slist* headers = NULL;
        headers = curl_slist_append(headers, "Content-Type: application/json");
        headers = curl_slist_append(headers, "X-RapidAPI-Key: 6fc2092ef9mshecbdeab13597fb4p1681c4jsn14ec229e4fe1");
        headers = curl_slist_append(headers, "X-RapidAPI-Host: microsoft-translator-text.p.rapidapi.com");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, requestBodyStr.c_str());

        // Response data
        std::string response_data;

        // Receive response
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, [](void* ptr, size_t size, size_t nmemb, std::string* stream) {
            *stream += std::string((char*)ptr, size * nmemb);
            return size * nmemb;
            });
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_data);

        // Perform the request
        CURLcode res = curl_easy_perform(curl);

        // Cleanup
        curl_easy_cleanup(curl);

        // Check for errors
        if (res != CURLE_OK) {
            std::cerr << "curl_easy_perform() failed: " << curl_easy_strerror(res) << std::endl;
            return "";
        }

        // Parse JSON response
        Json::Value root;
        Json::Reader reader;
        if (!reader.parse(response_data, root)) {
            std::cerr << "Failed to parse JSON response" << std::endl;
            return "";
        }

        try
        {
            std::string translated_text = root[0]["translations"][0]["text"].asString();
            return translated_text;
        }
        catch (const std::exception&)
        {
            return "";
        }

        // Extract translated text
        
    }
    return "";
}



int main()
{
    crow::SimpleApp app; //define your crow application

    CROW_ROUTE(app, "/")([]() {
        auto page = crow::mustache::load_text("textInput.html");
        return page;
    });

    CROW_ROUTE(app, "/post").methods("POST"_method)([](const crow::request& req) {
        std::string textString = req.get_body_params().get("text");

        std::string returnText = "";

        

        if (textString.empty()) {
            returnText = "No text rendered";
        }
        else {
            std::vector<std::string> found_sources = getFoundSourcesFromInternet(textString);

            if (found_sources.size() == 0) {
                std::string textStringInEnglish = translateText("en", textString);

                if (textStringInEnglish == "") {
                    returnText = "Some error happened or text language is unidentified";
                }
                else {
                    std::vector<std::string> found_sources2 = getFoundSourcesFromInternet(textStringInEnglish);

                    if (found_sources2.size() == 0) {
                        returnText = "No plagarism was found!";
                    }
                    else {
                        returnText = "Plagarism found! Language: Uzbek. Sources: ";
                        for (int i = 0; i < found_sources2.size(); i++)
                        {
                            returnText += std::string(found_sources2[i]);
                        }
                    }
                }
            }
            else {
                returnText = "Plagarism found! Language: English. Sources:";
                for (int i = 0; i < found_sources.size(); i++)
                {
                    returnText += std::string(found_sources[i]);
                }
            }
        }
        

        auto page = crow::mustache::load("result.html");
        crow::mustache::context ctx({ {"content", returnText} });

        return page.render(ctx);
    });

    //set the port, set the app to run on multiple threads, and run the app
    app.port(18080).multithreaded().run();
}

